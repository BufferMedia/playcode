import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-category-game-list',
  templateUrl: './category-game-list.component.html',
  styleUrls: ['./category-game-list.component.css']
})
export class CategoryGameListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
