import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-auth-menu',
  templateUrl: './auth-menu.component.html',
  styleUrls: ['./auth-menu.component.scss']
})
export class AuthMenuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
