import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-game-profile-review',
  templateUrl: './game-profile-review.component.html',
  styleUrls: ['./game-profile-review.component.css']
})
export class GameProfileReviewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
