import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-register-personalization',
  templateUrl: './register-personalization.component.html',
  styleUrls: ['./register-personalization.component.scss']
})
export class RegisterPersonalizationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
