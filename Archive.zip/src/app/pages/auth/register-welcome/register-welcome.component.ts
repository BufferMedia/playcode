import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-register-welcome',
  templateUrl: './register-welcome.component.html',
  styleUrls: ['./register-welcome.component.scss']
})
export class RegisterWelcomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
