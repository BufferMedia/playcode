import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-register-gender',
  templateUrl: './register-gender.component.html',
  styleUrls: ['./register-gender.component.scss']
})
export class RegisterGenderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
