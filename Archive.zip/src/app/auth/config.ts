import { Observable } from 'rxjs';
import {HttpClient} from '@angular/common/http';

export class Config {

  public static readonly apiUrl = 'http://localhost/Project-Easytax/git/easytax-framework/api/';


}


