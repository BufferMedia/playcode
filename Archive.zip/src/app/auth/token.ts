import { Observable } from 'rxjs';
import {HttpClient} from '@angular/common/http';

export class Token {

  public jwt;
  public refreshToken;


}


